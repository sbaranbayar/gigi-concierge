import {env} from 'cloudflare:workers';
import {publicAIStatus} from '../../../lib/ai-config';
export async function GET(){return Response.json(publicAIStatus(env as unknown as Record<string,string>),{headers:{'Cache-Control':'no-store'}});}
