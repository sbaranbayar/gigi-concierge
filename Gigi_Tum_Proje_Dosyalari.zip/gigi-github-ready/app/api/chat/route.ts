import {env} from 'cloudflare:workers';
import {normalizePayload,answerChat} from '../../../lib/model';
import {resolveAIConfig} from '../../../lib/ai-config';
export async function POST(request:Request){
 if(Number(request.headers.get('content-length')||0)>150000)return Response.json({error:'Message too large.'},{status:413});
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return Response.json({error:'Invalid origin.'},{status:403});
 try{const raw=await request.text();if(raw.length>150000)return Response.json({error:'Message too large.'},{status:413});let payload;try{payload=normalizePayload(JSON.parse(raw));}catch{return Response.json({error:'Please enter a valid message.'},{status:400});}const answer=await answerChat(payload,resolveAIConfig(env as unknown as Record<string,string>));return Response.json(answer,{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'Please try again.'},{status:500});}
}
