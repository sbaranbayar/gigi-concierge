import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Gigi · Your Go Gator Concierge",
  description: "A thoughtful stay starts with a good conversation. Explore the fictional Go Gator Resort & Spa with Gigi.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
