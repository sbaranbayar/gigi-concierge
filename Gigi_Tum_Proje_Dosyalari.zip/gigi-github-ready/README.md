# Gigi · Go Gator Resort & Spa

A multilingual classroom hotel concierge for Dr. Hengxuan (Oscar) Chi's HFT 4442 / HMG 6440 final project. Team: Sinan Baran Bayar, Brooke Davidson, Eli Kelford and Pamela Vishka.

**Current state:** the app works in hotel guide mode without an API key. Gemini and OpenAI server adapters are implemented, but no live language-model response has been verified. Human requests generate **prepared, unsent** summaries. There is no connected booking system, live inventory, payment processor or employee messaging.

## Run on your computer

Install Node.js 24 and pnpm 11.25.0. If pnpm is not installed, run `npm install --global pnpm@11.25.0` once. Open a terminal in this folder:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open **http://localhost:5173**. No key, credit card or login is needed for local guide mode. This is a local development server; internet access is required to download dependencies and for any optional cloud-model requests.

Start with [TEAM_START_HERE.md](TEAM_START_HERE.md). The full source, instructor hotel knowledge and resort images are included. Dependencies and actual secret files are excluded.

## What the team can review

- Responsive interface with Gigi's avatar, chat, guide search, room comparisons, dining, spa, map and service-request summaries.
- English by default, with Spanish and Simplified Chinese.
- All 17 original hotel sections and 142 curated facts, including policy-conflict qualifications.
- Five normal-chat scenarios in Demo studio: information, recommendations, multi-turn context, difficult interaction and human handoff.
- Optional browser speech. Actual microphone/speaker performance depends on permissions, browser support and installed voices and has not been verified.

## Checks

```sh
pnpm typecheck
pnpm test
pnpm build
```

The guide suite has 70 checks. The model-adapter suite has 16 checks using mocked responses. Passing mocks does **not** demonstrate a live LLM connection or factual quality of generated replies. GitHub Actions runs the same type, test, server-build and static-build checks without an API key; it does not deploy or call a paid model.

## Optional live Gemini

Keep the app in guide mode while reviewing it. A live Gemini connection requires a usable Gemini API key and account/project quota. To configure **local development**, copy `.env.example` to `.dev.vars`, then enter the key there using your editor:

```dotenv
AI_PROVIDER=gemini
GEMINI_MODEL=gemini-3.5-flash
GEMINI_API_KEY=
```

Restart the dev server after changing the file. Do not commit `.dev.vars` or send keys in issues, chats or screenshots. `/api/status` shows configuration; only a successful validated model reply is labeled as AI assisted. Rate limits, blocked or malformed output, and network failures return an explicitly labeled guide answer. An explicit Gemini selection never switches to OpenAI automatically.

Gemini's free tier is limited and eligibility is account/project dependent. Free-tier content may be used to improve Google's products; use fictional classroom guest data. [Official pricing](https://ai.google.dev/gemini-api/docs/pricing) and [key setup](https://ai.google.dev/gemini-api/docs/api-key) explain current conditions.

OpenAI remains an explicit alternative using `AI_PROVIDER=openai`, `OPENAI_API_KEY` and an accessible `OPENAI_MODEL`. No real credentials are included in this repository.

## One-file browser demo for GitHub Pages

Run `pnpm build:pages` to generate **`pages-dist/index.html`**. The file embeds its images, CSS and JavaScript. It can be opened locally or uploaded to a GitHub Pages repository at any project path. No build step is needed on GitHub when using this prebuilt file. This version always uses the hotel guide and makes no AI API requests; cloud-model access remains a server feature of the full app.

The prebuilt, self-contained demo is included at `demo/index.html`. Open it in a browser or upload that file to a separate GitHub Pages repository. Follow `PROJEYI_OKU.txt` for the two sharing options. GitHub Free requires a public repository for Pages; the demo and included fictional hotel information then become public. A private source repository and a public Pages site have different audiences; choose which to use before publishing.

## Sharing and hosting

GitHub hosts the **source**. It does not automatically run this full application. Invite teammates to the private repository for code review, or let them run this local copy. GitHub Pages serves static sites and cannot run the server routes that hold model credentials. A live full application needs a compatible server/Cloudflare Workers host and separately configured secrets.

This export has no personal Sites project ID or source-repository credentials. Its source was exported from the deployed Gigi version; the original deployed Site is independent. The retained Sites/Vinext integration supports local development, but this snapshot does not grant access to the existing private Site or automatically synchronize future edits back to it.

## Project map

| Path | Purpose |
| --- | --- |
| `app/page.tsx`, `app/globals.css` | Interface and responsive styling |
| `data/knowledge.json` | Instructor case text, curated facts and source references |
| `lib/concierge.ts`, `lib/legacy-engine.ts` | Guide retrieval, temporary context and prepared handoffs |
| `lib/model.ts`, `lib/ai-config.ts` | Provider selection, grounding instructions and validation |
| `app/api/chat`, `app/api/status` | Server-only chat and non-secret connection status |
| `public/assets` | Gigi and instructor resort images |
| `tests` | Guide, mocked adapter and earlier browser QA evidence |
| `docs` | Requirements and video-readiness audit |

Conversation context is temporary and resets when the page reloads. Known source IDs and valid JSON are useful checks; they do not prove that every generated hotel statement is correct. Final recording still needs successful real-model tests, physical audio testing if used, and an actually timed 60-second rehearsal.
