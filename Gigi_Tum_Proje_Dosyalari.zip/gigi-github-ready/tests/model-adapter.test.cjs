const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
fs.mkdirSync(path.join(root, '.qa/lib'), {recursive: true});
fs.mkdirSync(path.join(root, '.qa/data'), {recursive: true});
fs.writeFileSync(path.join(root, '.qa/package.json'), '{"type":"commonjs"}');
for (const name of ['legacy-engine', 'concierge', 'model', 'ai-config']) {
  fs.writeFileSync(path.join(root, '.qa/lib', name + '.js'), ts.transpileModule(
    fs.readFileSync(path.join(root, 'lib', name + '.ts'), 'utf8'),
    {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true}},
  ).outputText);
}
fs.copyFileSync(path.join(root, 'data/knowledge.json'), path.join(root, '.qa/data/knowledge.json'));
const {answerChat, normalizePayload} = require('../.qa/lib/model.js');
const {resolveAIConfig, publicAIStatus} = require('../.qa/lib/ai-config.js');
const results = [];
const payload = () => normalizePayload({message: 'What time does the Go Gator Buffet open, and is breakfast included?', lang: 'en'});
const generated = (changes = {}) => ({answer: 'The Go Gator Buffet opens at 6:30 AM. Breakfast is included in the all-inclusive plan.', sourceIds: ['s4-dining-buffet'], supported: true, requiresHuman: false, department: 'none', ...changes});
const gemini = (result = generated(), changes = {}) => ({candidates: [{finishReason: 'STOP', content: {parts: [{text: JSON.stringify(result)}]}}], ...changes});
const config = (fetch) => ({provider: 'gemini', apiKey: 'test-fixture-only', model: 'gemini-3.5-flash', fetch});
const ok = (data) => new Response(JSON.stringify(data), {headers: {'Content-Type': 'application/json'}});
async function check(name, fn) {
  try {await fn(); results.push({name, pass: true});}
  catch (error) {results.push({name, pass: false, error: error.message});}
}

(async () => {
  await check('Public status never includes the configured key or claims a verified connection', () => {
    const env = {AI_PROVIDER: 'gemini', GEMINI_API_KEY: 'test-fixture-only'};
    const status = publicAIStatus(env);
    assert.equal(status.configured, true);
    assert.equal(status.connected, false);
    assert.equal(status.model, 'gemini-3.5-flash');
    assert(!JSON.stringify(status).includes(env.GEMINI_API_KEY));
    assert.equal(publicAIStatus({AI_PROVIDER: 'gemini'}).configured, false);
  });
  await check('Selecting Gemini cannot silently use an existing paid OpenAI key', () => {
    const settings = resolveAIConfig({AI_PROVIDER: 'gemini', OPENAI_API_KEY: 'test-openai-only', OPENAI_MODEL: 'gpt-6.1-terra'});
    assert.equal(settings.provider, 'gemini');
    assert.equal(settings.apiKey, undefined);
    assert.equal(publicAIStatus({AI_PROVIDER: 'unknown', OPENAI_API_KEY: 'test-openai-only', OPENAI_MODEL: 'gpt-6.1-terra'}).configured, false);
  });
  await check('Gemini request preserves complete hotel evidence, language and multi-turn context', async () => {
    let calls = 0;
    const input = normalizePayload({message: 'What about the evening?', lang: 'es', history: [{role: 'user', content: 'Is the Kids Club included?'}, {role: 'assistant', content: 'Daytime Kids Club is included.'}]});
    const result = await answerChat(input, config(async (url, options) => {
      calls++;
      assert.equal(new URL(url).origin, 'https://generativelanguage.googleapis.com');
      assert.equal(new URL(url).search, '');
      assert.equal(options.headers['x-goog-api-key'], 'test-fixture-only');
      const body = JSON.parse(options.body);
      assert(!options.body.includes('test-fixture-only'));
      const system = body.systemInstruction.parts[0].text;
      assert(system.includes('Selected language: es'));
      for (let section = 1; section <= 17; section++) assert(system.includes('"id":"case-' + section + '"'));
      assert(system.includes('No real hotel system or employee communication is connected'));
      assert.equal(body.contents[0].parts[0].text, input.history[0].content);
      assert.equal(body.contents[1].role, 'model');
      assert.equal(body.contents[2].parts[0].text, input.message);
      return ok(gemini(generated({answer: 'Las sesiones nocturnas del Kids Club tienen un cargo adicional.', sourceIds: ['s6-kids-evening']})));
    }));
    assert.equal(calls, 1);
    assert.equal(result.mode, 'llm');
    assert.equal(result.provider, 'gemini');
    assert.equal(result.connected, true);
    assert.deepEqual(result.sourceIds, ['s6-kids-evening']);
  });
  await check('Unknown source IDs cannot appear as a model-supported answer', async () => {
    const result = await answerChat(payload(), config(async () => ok(gemini(generated({sourceIds: ['invented-source']})))));
    assert.equal(result.mode, 'guide');
    assert.equal(result.connected, false);
    assert.equal(result.fallbackReason, 'invalid_output');
  });
  await check('Unsupported answers and false completed-action claims fall back to the guide', async () => {
    for (const output of [generated({supported: false}), generated({answer: 'I have booked your room.'})]) {
      const result = await answerChat(payload(), config(async () => ok(gemini(output))));
      assert.equal(result.fallback, true);
      assert.equal(result.mode, 'guide');
      assert(!result.text.includes('I have booked'));
    }
  });
  await check('A truncated or blocked Gemini response is never reported as connected', async () => {
    for (const data of [{candidates: [{finishReason: 'MAX_TOKENS'}]}, {promptFeedback: {blockReason: 'SAFETY'}}, {candidates: []}]) {
      const result = await answerChat(payload(), config(async () => ok(data)));
      assert.equal(result.connected, false);
      assert.equal(result.fallbackReason, 'invalid_output');
    }
  });
  await check('Thinking text is excluded from the guest reply', async () => {
    const data = gemini();
    data.candidates[0].content.parts.unshift({thought: true, text: 'Internal thought, not an answer.'});
    const result = await answerChat(payload(), config(async () => ok(data)));
    assert.equal(result.mode, 'llm');
    assert(!result.text.includes('Internal thought'));
  });
  await check('Quota errors make one request and clearly identify a guide response', async () => {
    let calls = 0;
    const result = await answerChat(payload(), config(async () => {calls++; return new Response('{}', {status: 429});}));
    assert.equal(calls, 1);
    assert.equal(result.fallbackReason, 'request_limit');
    assert.match(result.fallbackMessage, /limit.*hotel guide/i);
    assert.equal(result.provider, null);
  });
  await check('Authentication failures do not leak provider messages or credentials', async () => {
    const result = await answerChat(payload(), config(async () => new Response('test-fixture-only', {status: 403})));
    assert.equal(result.fallbackReason, 'authentication');
    assert(!JSON.stringify(result).includes('test-fixture-only'));
  });
  await check('Network timeouts retain a usable guide answer', async () => {
    const result = await answerChat(payload(), config(async () => {throw new DOMException('timeout', 'TimeoutError');}));
    assert.equal(result.fallbackReason, 'timeout');
    assert(result.text.length > 0);
    assert.equal(result.connected, false);
  });
  await check('Human requests and safety branches do not wait on model availability', async () => {
    for (const message of ['I want to speak to a manager about a refund for my stay.', 'Can an actual person take over?']) {
      let called = false;
      const result = await answerChat(normalizePayload({message}), config(async () => {called = true; throw Error('must not call');}));
      assert.equal(called, false);
      assert(result.handoff);
      assert.equal(result.mode, 'guide');
      assert.equal(result.connected, false);
    }
  });
  await check('A model-recognized escalation prepares an unsent employee summary', async () => {
    const result = await answerChat(payload(), config(async () => ok(gemini(generated({answer: 'The Concierge should confirm your request.', requiresHuman: true, department: 'concierge'})))));
    assert.equal(result.mode, 'llm');
    assert.equal(result.handoff.department.toLowerCase(), 'concierge');
    assert.match(result.text, /not sent|prepare|cannot send|not.*contacted/i);
  });
  await check('Invalid human-routing fields cannot bypass output validation', async () => {
    for (const invalid of [{requiresHuman: 'false'}, {department: 'invented-department'}]) {
      const result = await answerChat(payload(), config(async () => ok(gemini(generated(invalid)))));
      assert.equal(result.fallbackReason, 'invalid_output');
    }
  });
  await check('OpenAI compatibility retains stateless structured Responses requests', async () => {
    const result = await answerChat(payload(), {provider: 'openai', apiKey: 'test-openai-only', model: 'gpt-6.1-terra', fetch: async (url, options) => {
      assert.equal(url, 'https://api.openai.com/v1/responses');
      const body = JSON.parse(options.body);
      assert.equal(body.store, false);
      assert.equal(body.text.format.strict, true);
      return ok({status: 'completed', output: [{type: 'message', content: [{type: 'output_text', text: JSON.stringify(generated())}]}]});
    }});
    assert.equal(result.provider, 'openai');
    assert.equal(result.mode, 'llm');
  });
  await check('Missing configuration and invalid model names never trigger an API call', async () => {
    let calls = 0;
    const fetch = async () => {calls++; throw Error('must not call');};
    await answerChat(payload(), {fetch});
    await answerChat(payload(), {...config(fetch), model: 'gemini-test?key=unsafe'});
    assert.equal(calls, 0);
    assert.equal(publicAIStatus({AI_PROVIDER: 'gemini', GEMINI_API_KEY: 'test-fixture-only', GEMINI_MODEL: '../invalid'}).configured, false);
  });
  await check('Guest email and card-like input are redacted before provider use', () => {
    const normalized = normalizePayload({message: 'My email is guest@example.com and card 4111 1111 1111 1111', history: [{role: 'user', content: 'guest@example.com'}]});
    assert(!JSON.stringify(normalized).includes('guest@example.com'));
    assert(!normalized.message.includes('4111'));
  });
  const failed = results.filter(r => !r.pass);
  fs.writeFileSync(path.join(root, 'tests/model-adapter-results.json'), JSON.stringify({verification: 'Mocked provider protocol and failure tests. No live Gemini response has been verified.', total: results.length, passed: results.length - failed.length, failed: failed.length, results}, null, 2) + '\n');
  console.log(JSON.stringify({total: results.length, passed: results.length - failed.length, failed: failed.length, failures: failed}, null, 2));
  if (failed.length) process.exitCode = 1;
})();
