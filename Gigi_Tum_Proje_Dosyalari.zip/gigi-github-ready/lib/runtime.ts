declare const __GIGI_INLINE_ASSETS__: Record<string, string> | undefined;
export const STATIC_DEMO = import.meta.env.VITE_GIGI_STATIC === 'true';
const inlineAssets = typeof __GIGI_INLINE_ASSETS__ === 'undefined' ? {} : __GIGI_INLINE_ASSETS__;
export function assetUrl(path: string) {
  return STATIC_DEMO ? inlineAssets?.[path] || path : path;
}
