export type AIProvider = 'gemini' | 'openai';

export function resolveAIConfig(env: Record<string, string | undefined>) {
  const requested = env.AI_PROVIDER?.trim().toLowerCase();
  const provider: AIProvider | null = requested
    ? requested === 'gemini' || requested === 'openai' ? requested : null
    : env.GEMINI_API_KEY?.trim() ? 'gemini' : 'openai';
  const apiKey = provider === 'gemini' ? env.GEMINI_API_KEY?.trim()
    : provider === 'openai' ? env.OPENAI_API_KEY?.trim() : undefined;
  const selectedModel = provider === 'gemini' ? env.GEMINI_MODEL?.trim() || 'gemini-3.5-flash'
    : provider === 'openai' ? env.OPENAI_MODEL?.trim() : undefined;
  const model = selectedModel && /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,99}$/.test(selectedModel)
    ? selectedModel : undefined;
  return {provider, apiKey, model};
}

// This is the only configuration shape returned to the browser. Never return env.
export function publicAIStatus(env: Record<string, string | undefined>) {
  const config = resolveAIConfig(env);
  return {
    configured: Boolean(config.apiKey && config.model),
    provider: config.provider,
    model: config.model || null,
    connected: false,
    mode: 'guide',
    bookingsConnected: false,
    staffConnected: false,
  };
}
