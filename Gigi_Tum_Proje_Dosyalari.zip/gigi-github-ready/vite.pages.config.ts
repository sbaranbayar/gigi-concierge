import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

const files = ['gigi.svg', 'resort.png', 'room.jpeg', 'buffet.jpeg', 'resort-map.jpeg', 'resort.svg'];
const assets = Object.fromEntries(files.map(name => {
  const mime = name.endsWith('.svg') ? 'image/svg+xml' : name.endsWith('.png') ? 'image/png' : 'image/jpeg';
  const data = readFileSync(new URL('./public/assets/' + name, import.meta.url)).toString('base64');
  return ['/assets/' + name, 'data:' + mime + ';base64,' + data];
}));

export default defineConfig({
  root: fileURLToPath(new URL('./pages-preview', import.meta.url)),
  publicDir: false,
  base: './',
  plugins: [react()],
  define: {
    'import.meta.env.VITE_GIGI_STATIC': JSON.stringify('true'),
    '__GIGI_INLINE_ASSETS__': JSON.stringify(assets),
  },
  build: {
    outDir: '../pages-dist',
    emptyOutDir: true,
    cssCodeSplit: false,
    modulePreload: false,
    chunkSizeWarningLimit: 10000,
  },
});
