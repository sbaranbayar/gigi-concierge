# Instructor guideline and video-readiness audit — 2 November 2026

## Source and scope

Re-read all 13 pages of `Final Project - Project Introduction_Chatbot 9.11 v2.docx`. Compared the deployed source against the 60-second Market Examination requirements (pages 9–10), the presentation requirements (page 11) and five live scenarios (page 12). Rechecked the actual guide engine with unfamiliar wording, not only the existing starter prompts.

## Verdict

The interface and case-based guide support a rehearsal. The project is not yet fully ready for final recording/submission as an LLM-powered agent. No language model is configured, no live provider call has been verified, physical voice has not been tested and no timed 60-second video exists. The 70 passing guide tests are a bounded regression set, not a guarantee of general conversation quality.

The five live scenarios belong to the approximately 12–15-minute final presentation. The separate 60-second video does **not** have to contain all five. It must show a guest interacting with Gigi, Gigi’s appearance, personality/communication, a realistic service interaction and a response to guest needs. Voice, photorealism and lip synchronization are not explicit requirements in the supplied guideline.

## Five live scenarios

| Scenario | Observed guide behavior | Qualification |
|---|---|---|
| Basic information | Published venue hours, room information and policy explanation | No live availability or completed reservation |
| Recommendation | Two-day suggestions, party/age context and appropriate case attractions | Not unrestricted language-model reasoning |
| Multi-turn context | Kids Club → evening → two-child fee → enrollment request | Broader phrasing still needs live model evaluation |
| Difficult interaction | Acknowledges complaint, distinguishes a cleaning/bedding request from money back | Human judgment and actual service remain outside the prototype |
| Human handoff | Recognizes explicit human request, prepares destination/extension/summary and preserves the complaint | No actual person joins; no request is sent |

The wording asks for recognition that a guest should be transferred and a justified escalation strategy. It does not explicitly require a real hotel call center or PMS. A clearly disclosed classroom handoff demonstration is defensible; the team must not claim a person has been contacted.

## Issues found and corrected

- `not money back` incorrectly triggered compensation: negation now recognized; fresh sheets route to Housekeeping without promising unspecified delivery timing.
- `an actual person take over` failed to open a prepared handoff: now recognized, while a negated human request is respected.
- `Tell me about The Waterfront` returned all dining entries: now remains on the named venue.
- A later manager request lost the original cleanliness complaint: the prepared summary now retains the original issue and subsequent request.
- Unresolved-help paraphrases retrieved unrelated facts: first asks a focused clarification; continued unresolved help escalates.

These are covered by the expanded 70-case regression record. The revised edition is deployed without a live model.

## Practical 60-second rehearsal

Use one coherent guest need, rather than compressing every feature into a minute. Suggested flow: guest with two children aged six and nine asks whether evening Kids Club is included; Gigi explains hours, cost and advance registration; guest asks Gigi to enroll the children; Gigi prepares a Concierge summary with status visibly not sent.

The actual current guide replies and their word count are recorded in `tests/video-readiness.json`. Its speech duration is an estimate using 150 words/minute, excluding introduction, closing, pauses, typing, clicks and model latency. It is not a timed recording. A real 60-second run must be measured on the recording computer after model and audio setup. Keep both a visible guest and Gigi’s avatar in the recording; the software cannot establish that a guest appears in a video that has not been recorded.

Survey satisfaction is the instructor’s 1–5 primary outcome. No real responses have been collected. The final presentation still needs the actual model/platform justification, psychological design, a justified AI/AI-assisted/human responsibility matrix, operational evaluation metrics and employee/organizational effects.

## Real model connection

The server adapter supports Gemini and OpenAI. No live generated reply has been verified. A usable API key and provider quota must be configured separately; no real key is included in this team export.

For Gemini, use `AI_PROVIDER=gemini`, server-held `GEMINI_API_KEY` and `GEMINI_MODEL` (default `gemini-3.5-flash`). The free tier depends on account/project eligibility and quota. An explicit Gemini selection never falls through to an existing OpenAI key. Configure the chosen host's secret and deploy before successful real calls and stress tests. Never place a key in chat, the browser bundle or the repository.

The adapter sends the hotel evidence and previous turns to the selected provider and requests structured JSON output. Mocked provider tests exercise both protocols and failure paths, including limits, truncation, blocked content, unsent handoffs and source validation. These tests are not live model results. Known source IDs and valid JSON do not prove factual correctness. Live tests must check unknown information, conflicting schedules, money/fees, authority limits, multilingual follow-ups and negation. Timing and model usage should be measured before recording. The current safety/action branches intentionally retain deterministic responses even when an optional model is configured.

Proposed measures: supported factual accuracy; follow-up/context success; appropriate escalation; median and p95 reply time; task success; average satisfaction (1–5). These are proposed evaluation measures, not observed operating statistics.

## Access

The original deployed Site is private. This source snapshot grants no access to that Site. Run this export locally for team review, or have the Site owner grant access separately.
