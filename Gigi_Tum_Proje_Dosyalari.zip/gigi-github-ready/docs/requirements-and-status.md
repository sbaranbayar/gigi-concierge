# Requirements and current evidence

| Requirement | Implemented evidence | Remaining verification |
|---|---|---|
| Hotel knowledge | 17 original sections and tables; 142 multilingual facts; original map | Instructor policy-conflict review |
| Virtual appearance | Original alligator character; responsive interface | Guest perceptions |
| Model/platform | Vinext/React; shared guide engine; Gemini and OpenAI server adapters; explicit provider selection | Provider key and successful live model tests pending |
| Context/recommendations | Party, age, topic and venue context; suggestions and comparisons | Unfamiliar language beyond bounded tests |
| Difficult interactions | Empathy; negation; desired resolution retained | Observed service recovery |
| Decision rights | AI explains/prepares; employee confirms/decides; unsent summaries | Actual staff integration absent |
| Evaluation | 70 recorded guide tests; browser and phone-width QA | Real survey and audio hardware |
| Market examination | 60-second storyboard | Team recording and instructor survey |
| Live demo | Five normal-chat starters and follow-ups | Team presentation/class stress test |
| Employee/organization | Decision-rights table and explicit limits | Discuss workload, training, monitoring, accountability and costs |

This classroom prototype runs in guide mode. It is not an operational hotel system.
