# Put this snapshot on GitHub

1. Create a new **private** repository named `gigi-concierge` in the intended owner account. Leave GitHub's initialization options blank because this folder already contains a README and ignore rules.
2. Extract the source ZIP locally. Upload the **contents** of its top-level `gigi-github-ready` folder, preserving nested paths. Include `.github`, `.openai`, `.gitignore`, `.env.example` and `.nvmrc`.
3. For a reliable upload with Git, initialize this exported folder, add its files, commit, set the default branch to `main`, add the exact HTTPS repository URL GitHub supplies as the `origin` remote, and push. This snapshot intentionally contains no old Git history or authenticated remote.
4. Confirm the repository remains private. Add teammates by their verified usernames under Settings → Collaborators → Add people. Invitations require acceptance before the private code becomes accessible to them.
5. Share the actual repository link. Teammates can clone it or use Code → Download ZIP, then follow the README.

GitHub Actions checks code after a push or pull request. It does not publish a website, change any Site's audience or request model access. The workflow has read-only repository content permission and does not use deployment credentials or AI keys. Its first GitHub-hosted run remains unverified until the repository is created and pushed.

Source export and website access are separate. If teammates only need to try the already deployed Gigi, the Site owner can grant Site access separately. Do not assume a GitHub invitation also grants access to that Site.

References:
- https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/repository-access-and-collaboration/inviting-collaborators-to-a-personal-repository
- https://docs.github.com/en/pages/getting-started-with-github-pages/about-github-pages
