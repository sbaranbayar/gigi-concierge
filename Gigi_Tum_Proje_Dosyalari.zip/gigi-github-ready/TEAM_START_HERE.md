# Team review: start here

## 1. Open Gigi

Follow the two commands in the README and open http://localhost:5173. Leave API keys unconfigured for the first review. Open **Demo studio** for the five scenario starters. These use the ordinary chat; you can replace every prompt with your own wording.

## 2. Try the five required skills

| Skill | First prompt | Follow-up to try |
| --- | --- | --- |
| Basic information | What time does the Go Gator Buffet open, and is breakfast included? | Do I need a reservation? |
| Recommendation | We are two adults and two children aged six and nine. Suggest a relaxed two-day stay. | Which room categories fit us? |
| Multi-turn context | Is the Kids Club included? | What about the evening? Then: How much for two children? |
| Difficult interaction | My room is not clean. This is unacceptable. | I do not want a refund. I just want the room cleaned. |
| Human handoff | I want to speak to a manager about a refund for my stay. | Can you approve the refund yourself? |

Check that the reply addresses the request, uses the right hotel facts, retains the relevant earlier details and explains uncertainty. A request needing staff should show a prepared summary. Nobody has been contacted and no booking/refund has been completed.

Also try unfamiliar wording, Spanish/Chinese, an underage Kids Club guest, a conflicting shuttle schedule, undated updates and an unknown facility. Record unexpected answers in a GitHub issue with the exact prompt, language, previous turns, expected result, actual result and whether the answer came from the guide or AI. Use fictional guest details.

## 3. Video and presentation

The five live scenarios belong to the final presentation. The separate **60-second customer video does not need all five**. Use one coherent service interaction: a family asks about evening Kids Club, follows up on the fee, then asks to enroll the children. Show Gigi's appearance and clear prepared-request status. Time an actual run before recording. The instructor's primary customer survey outcome is satisfaction from 1 to 5.

Do not describe the project as connected to a live LLM until a successful real response has been verified. The current model-adapter tests use mocks. Voice input/output, real guest survey results and actual employee integration are unverified.

## 4. Contribute

Work on a branch, make a focused change, run `pnpm typecheck`, `pnpm test` and `pnpm build`, then open a pull request. Preserve the original hotel facts and disclose source conflicts. No actual API key belongs in a commit. The GitHub checks use no live AI calls.

Keep this course repository private. Add teammates by their confirmed GitHub usernames under repository Settings → Collaborators → Add people. The repository owner will manage invitations; no invitations were sent while preparing this export.
